@echo off
setlocal
call "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b 1
set "PTK=E:\Program Files\PTC\Creo 10.0.0.0\Common Files\protoolkit"
pushd "%~dp0"
set "BUILD_DIR=%~dp0..\..\work\native-build"
if not exist "%BUILD_DIR%" mkdir "%BUILD_DIR%"
cl /nologo /MD /W3 /utf-8 /GS /DPRO_MACHINE=36 /DPRO_OS=4 /I"%PTK%\includes" /c src\assistant.c /Fo"%BUILD_DIR%\assistant.obj"
if errorlevel 1 exit /b 1
link /nologo /DLL /MACHINE:X64 /OUT:codex_native_ai_v18_named_versioned.dll /IMPLIB:"%BUILD_DIR%\codex_native_ai_v18_named_versioned.lib" "%BUILD_DIR%\assistant.obj" "%PTK%\x86e_win64\obj\protk_dllmd_NU.lib" "%PTK%\x86e_win64\obj\ucore.lib" "%PTK%\x86e_win64\obj\udata.lib" kernel32.lib user32.lib wsock32.lib advapi32.lib mpr.lib winspool.lib netapi32.lib psapi.lib gdi32.lib shell32.lib comdlg32.lib ole32.lib ws2_32.lib
set "BUILD_RESULT=%ERRORLEVEL%"
popd
exit /b %BUILD_RESULT%
