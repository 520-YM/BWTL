! Opens the native in-process Creo TOOLKIT window.
mapkey cdx @MAPKEY_LABELCodex Assistant;~ Command `CodexNativeOpen`;
